(** Order of list is Andrew Lou; Huy Nguyen; Andrew Wang*)
let hours_worked = [ 19; 19; 29 ]
