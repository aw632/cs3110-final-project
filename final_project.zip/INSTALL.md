# Installation instructions:

1. Download and extract the zip file.
2. In terminal, run `make build`.
3. In terminal, run `make calc`.
4. Enjoy the calculator!

*Note: no additional commands should be required.*